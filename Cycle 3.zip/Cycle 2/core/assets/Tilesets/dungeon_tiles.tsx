<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.2" name="dungeon_tiles" tilewidth="32" tileheight="32" tilecount="132" columns="11">
 <image source="dungeon_tiles.png" width="368" height="384"/>
</tileset>
